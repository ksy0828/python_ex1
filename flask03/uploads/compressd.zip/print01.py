print("Hello, python")

print("파이썬\n", "웰컴\n")
print("""굉장히 긴
    문자열입니다.....""")

print("헬로우\t파이썬")

print('이렇게도 되나?')

print('이건 "강조" 하기')